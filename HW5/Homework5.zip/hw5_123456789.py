import cv2
import numpy as np
from scipy.signal import convolve2d as conv
import matplotlib.pyplot as plt


def sobel(im):

    return new_im


def canny(im):
    return cv2.Canny()


def hough_circles(im):
    im_c = im.copy()
    
    return im_c


def hough_lines(im):
    im_l = im.copy()
    
    return im_l
