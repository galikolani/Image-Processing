function [a,b] = myAdd(c,d)
% this function/////

a = c + d;
b = c-d;
end

