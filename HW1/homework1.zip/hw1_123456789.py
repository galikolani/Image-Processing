import numpy as np
import matplotlib.pyplot as plt
import cv2

def histImage(im):

    return h


def nhistImage(im):

    return nh


def ahistImage(im):

    return ah


def calcHistStat(h):

    return m, e


def mapImage(im,tm):

    return nim


def histEqualization(im):
    
    return tm

